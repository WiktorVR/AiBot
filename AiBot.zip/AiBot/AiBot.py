#welcomepython
#check.json
#write

#imports
import random
import os
import psutil
import webbrowser
import time
import pyperclip
import shutil
#os import as AI

#songconfig.json(.run)

#Welcome
print ("Hello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
q = input("\nType : ")

#QtA Query to Answers
if (q == "hi") :
    WORDS = ("Hi.", "Hello!", "Good day!", "Hi, my day is good!", "Hi, i guess.\nAnswering your questions...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")


if (q == "hi, how are you?") :
    HAY = ("I would say... umm....\nNot sure?!", "Well i guess", "My day is pretty good", "Good day? Yes good day!", "Fully awesome. \nFully happy. \nFully feeling great!")
    wordhay = random.choice(HAY)
    correct = wordhay

    print(wordhay)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "how are you") :
    HAY = ("I would say... umm....\nNot sure?!", "Well i guess, oookkkk?", "My day is pretty good", "Good day? Yes good day!", "Fully awesome. \nFully happy. \nFully feeling great!")
    wordhay = random.choice(HAY)
    correct = wordhay

    print(wordhay)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "are you ok") :
    HAY = ("I would say... umm....\nNot sure?!", "Well i guess, oookkkk?", "My day is pretty good", "Good day? Yes good day!", "Fully awesome. \nFully happy. \nFully feeling great!")
    wordhay = random.choice(HAY)
    correct = wordhay

    print(wordhay)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "hello") :
    WORDS = ("Hi.", "Hello!", "Good day!", "Hi, my day is good!", "Hi, i guess.\nAnswering your questions...", "Hello buddy.\n\nok you can go now...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "exit") :
    print("quitting...")

if (q == "quit") :
    print ("")

if (q == "what are you doing") :
    WORDS = ("Im answering your questions.", "Im inside your computer...", "Do you seriously not know!", "HOW DO YOU NOT KNOW!", "Answering questiions,\nlearning every day!")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "tell me a joke") :
    WORDS = ("Ok, get ready. Here we go.\nI'm a big fan of whiteboards. I find them quite re-markable. Get it. Whiteboards use markers to write on.\nand re(MARKABLE). No?\nOK?!", "Ok,  Did you hear about the racing snail who got rid of his shell?\nHe thought it would make him faster, but it just made him sluggish!\nFunny, right?", "Two men are hiking through the woods when one of them cries out, “Snake! Run!” His companion laughs at him.\n“Oh, relax. It’s only a baby,” he says. “Don’t you hear the rattle?”\nGet it, because babies play with rattles and snakes make a rattle noise.\nRight, right? Get it? Ok...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "tell me a joke please") :
    WORDS = ("Ok, get ready. Here we go.\nI'm a big fan of whiteboards. I find them quite re-markable. Get it. Whiteboards use markers to write on.\nand re(MARKABLE). No?\nOK?!", "Ok,  Did you hear about the racing snail who got rid of his shell?\nHe thought it would make him faster, but it just made him sluggish!\nFunny, right?", "Two men are hiking through the woods when one of them cries out, “Snake! Run!” His companion laughs at him.\n“Oh, relax. It’s only a baby,” he says. “Don’t you hear the rattle?”\nGet it, because babies play with rattles and snakes make a rattle noise.\nRight, right? Get it? Ok...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "tell a joke please") :
    WORDS = ("Ok, get ready. Here we go.\nI'm a big fan of whiteboards. I find them quite re-markable. Get it. Whiteboards use markers to write on.\nand re(MARKABLE). No?\nOK?!", "Ok,  Did you hear about the racing snail who got rid of his shell?\nHe thought it would make him faster, but it just made him sluggish!\nFunny, right?", "Two men are hiking through the woods when one of them cries out, “Snake! Run!” His companion laughs at him.\n“Oh, relax. It’s only a baby,” he says. “Don’t you hear the rattle?”\nGet it, because babies play with rattles and snakes make a rattle noise.\nRight, right? Get it? Ok...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "joke please") :
    WORDS = ("Ok, get ready. Here we go.\nI'm a big fan of whiteboards. I find them quite re-markable. Get it. Whiteboards use markers to write on.\nand re(MARKABLE). No?\nOK?!", "Ok,  Did you hear about the racing snail who got rid of his shell?\nHe thought it would make him faster, but it just made him sluggish!\nFunny, right?", "Two men are hiking through the woods when one of them cries out, “Snake! Run!” His companion laughs at him.\n“Oh, relax. It’s only a baby,” he says. “Don’t you hear the rattle?”\nGet it, because babies play with rattles and snakes make a rattle noise.\nRight, right? Get it? Ok...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "joke") :
    WORDS = ("Ok, get ready. Here we go.\nI'm a big fan of whiteboards. I find them quite re-markable. Get it. Whiteboards use markers to write on.\nand re(MARKABLE). No?\nOK?!", "Ok,  Did you hear about the racing snail who got rid of his shell?\nHe thought it would make him faster, but it just made him sluggish!\nFunny, right?", "Two men are hiking through the woods when one of them cries out, “Snake! Run!” His companion laughs at him.\n“Oh, relax. It’s only a baby,” he says. “Don’t you hear the rattle?”\nGet it, because babies play with rattles and snakes make a rattle noise.\nRight, right? Get it? Ok...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "what is the time") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "time") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "time please") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "can you tell me the time") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "can you tell me the time please") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "clock") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "clock please") :
    from datetime import datetime
    print ("The Time Is : ", datetime.now().time().strftime('%H:%M'))
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "play some music") :
    musicwhat = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicwhat == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicwhat == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicwhat == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "music") :
    musicwhat = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicwhat == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicwhat == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicwhat == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "music please") :
    musicwhat = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicwhat == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicwhat == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicwhat == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "play some music please") :
    musicwhat = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicwhat == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicwhat == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicwhat == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "play music") :
    musicwhat = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicwhat == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicwhat == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicwhat == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "what ya doing") :
    WORDS = ("Im answering your questions.", "Im inside your computer...", "Do you seriously not know!", "HOW DO YOU NOT KNOW!", "Answering questiions,\nlearning every day!")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "what you are doing") :
    WORDS = ("Im answering your questions.", "Im inside your computer...", "Do you seriously not know!", "HOW DO YOU NOT KNOW!", "Answering questiions,\nlearning every day!")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "what you doing") :
    WORDS = ("Im answering your questions.", "Im inside your computer...", "Do you seriously not know!", "HOW DO YOU NOT KNOW!", "Answering questiions,\nlearning every day!")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "helo") :
    WORDS = ("helloooooooo!", "hi, i guess.", "Hi. By the way thats not how you spell hello, helo guy!", "HAYYEE!", "Hi, im a ai robot which is learning every day.")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "LOL") :
    WORDS = ("LOL back!", "LOL!", "HAHA, funny...", "Oh yeah, that old shorterner. LAUGH OUT LOUD!", "Why you laughing, huh, huh? Why are yoo laughing\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!", "Funny,\n\n\n\n\n\n\n\n\n\nYou think... XD")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "lol") :
    WORDS = ("LOL back!", "LOL!", "HAHA, funny...", "Oh yeah, that old shorterner. LAUGH OUT LOUD!", "Why you laughing, huh, huh? Why are yoo laughing\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!", "Funny,\n\n\n\n\n\n\n\n\n\nYou think... XD")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "laugh out loud") :
    WORDS = ("LOL back!", "LOL!", "HAHA, funny...", "Oh yeah, that old shorterner. LAUGH OUT LOUD!", "Why you laughing, huh, huh? Why are yoo laughing\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!\nHUH?!", "Funny,\n\n\n\n\n\n\n\n\n\nYou think... XD")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "make a note") :
    note = input("Write note : ")
    enterveri = input("Verification captia for words. Type in the following (all lowercase),\nehuret15m\n : ")
    if (enterveri == "ehuret15m") :
        noteenter = input("Press Enter (WITH NO EXTRA LETTERS!) to confirm...")
        if (noteenter == "") :
            with open('Notes.txt', 'a') as f:
                f.write('\n---------------------------------------------------------------------\n{} {}'.format(note, noteenter))


if (q == "note") :
    note = input("Write note : ")
    enterveri = input("Verification captia for words. Type in the following (all lowercase),\nehuret15m\n : ")
    if (enterveri == "ehuret15m") :
        noteenter = input("Press Enter (WITH NO EXTRA LETTERS!) to confirm...")
        if (noteenter == "") :
            with open('Notes.txt', 'a') as f:
                f.write('\n---------------------------------------------------------------------\n{} {}'.format(note, noteenter))

if (q == "make note") :
    note = input("Write note : ")
    enterveri = input("Verification captia for words. Type in the following (all lowercase),\nehuret15m\n : ")
    if (enterveri == "ehuret15m") :
        noteenter = input("Press Enter (WITH NO EXTRA LETTERS!) to confirm...")
        if (noteenter == "") :
            with open('Notes.txt', 'a') as f:
                f.write('\n---------------------------------------------------------------------\n{} {}'.format(note, noteenter))

if (q == "good") :
    WORDS = ("Nice!", "great...", "ok", "fine", "hmmm...ok i guess?", "not sure...\nyour welcome")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "ok") :
    WORDS = ("ok\n...", "ok... what now?", "Your Welcome,\nWant any other help?", "ok.\nnice.\nwhatdo you want from me?!", "ok")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "thank you") :
    WORDS = ("Your\nWelcome!", "There you go!", "Your welcome!", "Thanks for saying thanks,\n\nI guess...", "No problem")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "youtube") :
    webbrowser.open('www.youtube.com', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "open youtube") :
    webbrowser.open('www.youtube.com', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "youtube please") :
    webbrowser.open('www.youtube.com', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "open youtube please") :
    webbrowser.open('www.youtube.com', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "yt") :
    webbrowser.open('www.youtube.com', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "yt please") :
    webbrowser.open('www.youtube.com', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "restart") :
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "reopen") :
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'nice') :
    WORDS = ("Nice!", "How are yooouuuu?", "Thanks...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'who are you') :
    WORDS = ("Who do you think?", "Im AiBot...", "What,\nSo...\n\nYou don't remember me?", "Really,\n you know...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'sing') :
    print("\nIm not sure how to sing but\nI can give you songs to listen to...\n\n1 = Yes please     2 = No thanks  ... : ")
    songyesno = input("")
    if (songyesno == "1") :
        musicinput = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicinput == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicinput == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicinput == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    if (songyesno == "2") :
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nOk...")
        stop = input("\n\n\nPress enter to continue...")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == 'sing please') :
    print("\nIm not sure how to sing but\nI can give you songs to listen to...\n\n1 = Yes please     2 = No thanks  ... : ")
    songyesno = input("")
    if (songyesno == "1") :
        musicinput = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicinput == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicinput == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicinput == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    if (songyesno == "2") :
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nOk...")
        stop = input("\n\n\nPress enter to continue...")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'can you sing') :
    print("\nIm not sure how to sing but\nI can give you songs to listen to...\n\n1 = Yes please     2 = No thanks  ... : ")
    songyesno = input("")
    if (songyesno == "1") :
        musicinput = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicinput == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicinput == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicinput == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    if (songyesno == "2") :
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nOk...")
        stop = input("\n\n\nPress enter to continue...")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'please sing') :
    print("\nIm not sure how to sing but\nI can give you songs to listen to...\n\n1 = Yes please     2 = No thanks  ... : ")
    songyesno = input("")
    if (songyesno == "1") :
        musicinput = input("a = Best hits 2021     b = Party Music    c = Summer mix : ")
    if (musicinput == "a") :
        webbrowser.open('https://www.youtube.com/watch?v=qclWIFxq2F4', new=2)
    if (musicinput == "b") :
        webbrowser.open('https://www.youtube.com/watch?v=bAEeDXInXyo', new=2)
    if (musicinput == "c") :
        webbrowser.open('https://www.youtube.com/watch?v=0GOU48eqVoQ', new=2)
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
    if (songyesno == "2") :
        print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nOk...")
        stop = input("\n\n\nPress enter to continue...")
        print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == "i don't know") :
    WORDS = ("IDK either....", "IDK?", "Hmm, I don't know.\nI don't know\nYou don't know\n\nEqual AiBot, IDK  ====  You, IDK")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'hmm') :
    WORDS = ("What?", "hmmmmmmm\nmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmmm\nmmmmmmmmmmmmmmmmmmmmmmmmmmmmm!", "Ok, hmm too...", "hmmmmmmm.")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == "") :
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'roll the dice') :
    WORDS = ("The number is 1", "The number is 2", "The number is 3", "The number is 4", "The number is 5", "The number is 6")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'dice') :
    WORDS = ("The number is 1", "The number is 2", "The number is 3", "The number is 4", "The number is 5", "The number is 6")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'roll dice') :
    WORDS = ("\nThe number is 1", "\nThe number is 2", "\nThe number is 3", "\nThe number is 4", "\nThe number is 5", "\nThe number is 6")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'heads or tails') :
    WORDS = ("\nIt's tails", "\nHeads Wins!", "\nNice, Tails!", "\nAll of you with heads out there. YOU WIN!\nBy the way it's heads...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'flip a coin') :
    WORDS = ("\nIt's tails", "\nHeads Wins!", "\nNice, Tails!", "\nAll of you with heads out there. YOU WIN!\nBy the way it's heads...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'flip the coin') :
    WORDS = ("\nIt's tails", "\nHeads Wins!", "\nNice, Tails!", "\nAll of you with heads out there. YOU WIN!\nBy the way it's heads...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'flip a coin please') :
    WORDS = ("\nIt's tails", "\nHeads Wins!", "\nNice, Tails!", "\nAll of you with heads out there. YOU WIN!\nBy the way it's heads...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'tails or heads') :
    WORDS = ("\nIt's tails", "\nHeads Wins!", "\nNice, Tails!", "\nAll of you with heads out there. YOU WIN!\nBy the way it's heads...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == 'settings') :
    setupsettings = input("1 = Query Answers   2 = Beta Developer Install : ")
    if (setupsettings == "2") :
        areyousurebeta = input("Are you sure... y/n : ")
        if (areyousurebeta == "n") :
                print("Cancelled. Restarting AiBot...")
                time.sleep(1)
                print("...")
                time.sleep(2)
                print("...")
                time.sleep(4)
                print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
                q = input("\nType : ")
        if (areyousurebeta == "y") :
            print("\n\n\n\n\nInstalling Beta Package...")
            time.sleep(1)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(3)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(3)
            print("...")
            time.sleep(1)
            print("...")
            time.sleep(3)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(5)
            print("Installing .py config...\n...")
            time.sleep(1)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(3)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(3)
            print("Beta config, activated. Starting shortcut.")
            print("...")
            time.sleep(1)
            print("...")
            time.sleep(3)
            print("...")
            time.sleep(2)
            print("Installing Packages")
            time.sleep(2)
            print("\n\nInstalling Beta Platform\nwww.betaplatform.com/AiBot/config.html/download.beta")
            print("...")
            time.sleep(6)
            print("...")
            time.sleep(1)
            print("...")
            time.sleep(2)
            print("...")
            time.sleep(3)
            print("...")
            time.sleep(4)
            print("...")
            time.sleep(1)
            print("Installed beta platform package... \nwww.betaplatform.com/AiBot/config.html/download.beta")
            time.sleep(9)
            print("Installed Beta Program...")
            print("\n\nWhat is the Beta Ai program?\nThis is where all the beta unstable features come out reguarly for testing.\nMore updates come out for the Ai side of things here.\nIf you're a experienced developer or you just want to test out the Ai plugin.\nThis is what it's for...")
            original = r'C:\Users\artur\Favorites\Desktop\Config\Beta'
            target = r'C:\Users\artur\Favorites\Desktop\AiBot'
            shutil.move(original,target)
            print("Go into the Beta folder in the AiBot folder to launch the beta version of AiBot\n\nOR\n\nYou could type 'beta' into the normal AiBot type section!")
            gotoornotai = input("Press 'enter' to launch AiBot BETA   |   Press '1' to relaunch the normal AiBot. : ")
            if (gotoornotai == "1") :
                print("Launching...")
                time.sleep(2)
                print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
                q = input("\nType : ")
            if (gotoornotai == "") :
                print("Launching Beta AiBot...")
                time.sleep(2)
                print("Preparing...")
                time.sleep(1)
                print("...")
                time.sleep(3)
                print("...")
                time.sleep(2)
                print("...")
                time.sleep(4)
                print("Launching...")
                time.sleep(2)
                print("...")
                time.sleep(3)
                print("...")
                time.sleep(1)
                os.startfile("C://Users/artur/Favorites/Desktop/AiBot/Beta/AiBot Beta.py")
    if (setupsettings == "1") :
        queriesanswers = input("\n1 = Whats your favourite ice cream    2 = What song do you like   3 = What should i do (For when you don't know what to do) : ")
        if (queriesanswers == "1") :
            icecreamq = input("Enter how AiBot should answer this question : ")
            pressenter = input("Press enter to confirm, (NO EXTRA LETTERS!) ")
            with open('icecream.txt', 'w') as f:
                f.write('{} {}'.format(icecreamq, pressenter))
                print("Editing...")
                time.sleep(4)
                print("Installing Packages...")
                time.sleep(2)
                print("...")
                time.sleep(3)
                print("...")
                time.sleep(1)
                print("\n\n\n\n\nEdited Query to : ", icecreamq)
                print("Type 'what ice cream do you like' to activate query")
                time.sleep(8)
                print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
                q = input("\nType : ")
    
        if (queriesanswers == "2") :
            songlike = input("Enter how AiBot should answer this question : ")
            pressenter = input("Press enter to confirm, (NO EXTRA LETTERS!) ")
            with open('songlike.txt', 'w') as f:
                f.write('{} {}'.format(songlike, pressenter))
                print("Editing...")
                time.sleep(4)
                print("Installing Packages...")
                time.sleep(2)
                print("...")
                time.sleep(3)
                print("...")
                time.sleep(1)
                print("\n\n\n\n\nEdited Query to : ", songlike)
                print("\nType 'what song do you like' to activate query")
                time.sleep(8)
                print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
                q = input("\nType : ")
                    
        if (queriesanswers == "3") :
            imbored = input("Enter how AiBot should answer this question : ")
            pressenter = input("Press enter to confirm, (NO EXTRA LETTERS!) ")
            with open('imboredsetup.txt', 'w') as f:
                f.write('{} {}'.format(imbored, pressenter))
                print("Editing...")
                time.sleep(4)
                print("Installing Packages...")
                time.sleep(2)
                print("...")
                time.sleep(3)
                print("...")
                time.sleep(1)
                print("\n\n\n\n\nEdited Query to : ", imbored)
                print("\nType 'im bored' to activate query")
                time.sleep(8)
                print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
                q = input("\nType : ")

if (q == "im bored") :
    f = open('imboredsetup.txt', 'r')
    file_contents = f.read()
    print("")
    print(file_contents)
    f.close()
    exitenter = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == "what song do you like") :
    f = open('songlike.txt', 'r')
    file_contents = f.read()
    print("")
    print(file_contents)
    f.close()
    exitenter = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
    
if (q == "what ice cream do you like") :
    f = open('icecream.txt', 'r')
    file_contents = f.read()
    print("")
    print(file_contents)
    f.close()
    exitenter = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == "beta") :
    os.startfile("C://Users/artur/Favorites/Desktop/AiBot/Beta/AiBot Beta.py")

if (q == 'so') :
    WORDS = ("Yeeah", "soo....", "so what...", "SO what?", "ok,\nnow tell me what...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print ("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\nHello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == 'no') :
    WORDS = ("Ok", "fine...", "no you...", "no no nooooooooooo hohohoho....\n(AiBot now does memes... yes...)")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print ("Hello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")

if (q == 'why') :
    WORDS = ("Idk", "Im not sure...", "Because...", "\n\n\n\n\n\n\n\nyes...\n\n(meme of 2018)", "Don't ask me...")
    word = random.choice(WORDS)
    correct = word

    print(word)
    stop = input("")
    print("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")
    print ("Hello, Im AiBot. Type any question and i'll try respond! Don't use capital letters!\nOnce you get output, press enter. Use punctuation properly as well.\n\nType 'settings' to set up stuff for AiBot to help you out with certain stuff.")
    q = input("\nType : ")
